# plugin.video.sosac.ph

**Kodi Addon for movies and tv shows**

 - Watch online movies and tv shows from www.sosac.tv.
 - This addon updated for Kodi 19 Matrix with python3